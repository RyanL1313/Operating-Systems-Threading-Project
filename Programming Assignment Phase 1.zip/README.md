# Operating-Systems-Threading-Project

Environment used: Java version 15.0.2, IntelliJ 2020.3.2

A dialog box will pop up upon starting the program where you must enter the full path of your file of processes.
From there, you will be taken to the window where you can run the simulation.

To get to the code, go to the "CS_490_GUI" folder, then the "src" folder, then the "Backend" folder.
We will change how those folders are structured in the future.
